import { StreamControllerCapabilities, StreamMouseButton, TransportChannelId } from "../api_bindings.js";
import { ByteBuffer, I16_MAX, U16_MAX, U8_MAX } from "./buffer.js";
import { emptyGamepadState, extractGamepadState, SUPPORTED_BUTTONS } from "./gamepad.js";
import { convertToKey, convertToModifiers } from "./keyboard.js";
import { convertToButton } from "./mouse.js";
// Smooth scrolling multiplier
const TOUCH_HIGH_RES_SCROLL_MULTIPLIER = 10;
// Normal scrolling multiplier
const TOUCH_SCROLL_MULTIPLIER = 1;
// Distance until a touch is 100% a click
const TOUCH_AS_CLICK_MAX_DISTANCE = 30;
// Time till it's registered as a click, else it might be scrolling
const TOUCH_AS_CLICK_MIN_TIME_MS = 100;
// Everything greater than this is a right click
const TOUCH_AS_CLICK_MAX_TIME_MS = 300;
// How much to move to open up the screen keyboard when having three touches at the same time
const TOUCHES_AS_KEYBOARD_DISTANCE = 100;
const CONTROLLER_RUMBLE_INTERVAL_MS = 60;
function trySendChannel(channel, buffer) {
    if (!channel) {
        return;
    }
    buffer.flip();
    const readBuffer = buffer.getRemainingBuffer();
    if (readBuffer.length == 0) {
        throw "illegal buffer size";
    }
    channel.send(readBuffer.buffer);
}
export function defaultStreamInputConfig() {
    return {
        mouseMode: "follow",
        mouseScrollMode: "highres",
        touchMode: "mouseRelative",
        controllerConfig: {
            invertAB: false,
            invertXY: false,
            sendIntervalOverride: null
        }
    };
}
export class StreamInput {
    constructor(config) {
        this.eventTarget = new EventTarget();
        this.buffer = new ByteBuffer(1024);
        this.connected = false;
        this.capabilities = { touch: true };
        // Size of the streamer device
        this.streamerSize = [0, 0];
        this.keyboard = null;
        this.mouseReliable = null;
        this.mouseAbsolute = null;
        this.mouseRelative = null;
        this.touch = null;
        this.controllers = null;
        this.controllerInputs = [];
        this.touchSupported = null;
        // -- Keyboard
        this.pressedKeys = new Set();
        // -- Touch
        this.touchTracker = new Map();
        this.touchMouseAction = "default";
        this.primaryTouch = null;
        // -- Controller
        // Wait for stream to connect and then send controllers
        this.bufferedControllers = [];
        this.gamepads = [];
        this.gamepadRumbleInterval = null;
        this.lastGamepadUpdate = performance.now();
        // -- Controller rumble
        this.gamepadRumbleCurrent = [];
        this.config = defaultStreamInputConfig();
        if (config) {
            this.setConfig(config);
        }
    }
    getDataChannel(transport, id) {
        const channel = transport.getChannel(id);
        if (channel.type == "data") {
            return channel;
        }
        throw `Failed to get channel ${id} as data transport channel`;
    }
    setTransport(transport) {
        this.keyboard = this.getDataChannel(transport, TransportChannelId.KEYBOARD);
        this.mouseReliable = this.getDataChannel(transport, TransportChannelId.MOUSE_RELIABLE);
        this.mouseAbsolute = this.getDataChannel(transport, TransportChannelId.MOUSE_ABSOLUTE);
        this.mouseRelative = this.getDataChannel(transport, TransportChannelId.MOUSE_RELATIVE);
        if (this.touch) {
            this.touch.removeReceiveListener(this.onTouchData.bind(this));
        }
        this.touch = this.getDataChannel(transport, TransportChannelId.TOUCH);
        this.touch.addReceiveListener(this.onTouchData.bind(this));
        if (this.controllers) {
            this.controllers.removeReceiveListener(this.onTouchData.bind(this));
        }
        this.controllers = this.getDataChannel(transport, TransportChannelId.CONTROLLERS);
        this.controllers.addReceiveListener(this.onControllerData.bind(this));
        this.controllerInputs.length = 0;
        for (let i = 0; i < 16; i++) {
            const channelId = TransportChannelId[`CONTROLLER${i}`];
            this.controllerInputs[i] = this.getDataChannel(transport, channelId);
        }
    }
    setConfig(config) {
        Object.assign(this.config, config);
        // Touch
        this.primaryTouch = null;
        this.touchTracker.clear();
    }
    getConfig() {
        return this.config;
    }
    getCapabilities() {
        return this.capabilities;
    }
    // -- External Event Listeners
    addScreenKeyboardVisibleEvent(listener) {
        this.eventTarget.addEventListener("ml-screenkeyboardvisible", listener);
    }
    // -- On Stream Start
    onStreamStart(capabilities, streamerSize) {
        this.connected = true;
        this.capabilities = capabilities;
        this.streamerSize = streamerSize;
        this.registerBufferedControllers();
    }
    onKeyDown(event) {
        this.sendKeyEvent(true, event);
    }
    onKeyUp(event) {
        this.sendKeyEvent(false, event);
    }
    onPaste(event) {
        const data = event.clipboardData;
        if (!data) {
            return;
        }
        console.debug("PASTE", data);
        const text = data.getData("text/plain");
        if (text) {
            console.debug("PASTE TEXT", text);
            // Before sending text raise all keys
            this.raiseAllKeys();
            this.sendText(text);
        }
    }
    sendKeyEvent(isDown, event) {
        const key = convertToKey(event);
        if (key == null) {
            return;
        }
        if (isDown) {
            if (this.pressedKeys.has(key)) {
                return;
            }
            this.pressedKeys.add(key);
        }
        else {
            if (!this.pressedKeys.has(key)) {
                return;
            }
            this.pressedKeys.delete(key);
        }
        const modifiers = convertToModifiers(event);
        if ("debug" in console) {
            console.debug(isDown ? "DOWN" : "UP", event.code, convertToKey(event), convertToModifiers(event).toString(16));
        }
        this.sendKey(isDown, key, modifiers);
    }
    raiseAllKeys() {
        for (const key of this.pressedKeys) {
            this.sendKey(false, key, 0);
        }
        this.pressedKeys.clear();
    }
    // Note: key = StreamKeys.VK_, modifiers = StreamKeyModifiers.
    sendKey(isDown, key, modifiers) {
        this.buffer.reset();
        this.buffer.putU8(0);
        this.buffer.putBool(isDown);
        this.buffer.putU8(modifiers);
        this.buffer.putU16(key);
        trySendChannel(this.keyboard, this.buffer);
    }
    sendText(text) {
        this.buffer.putU8(1);
        this.buffer.putU8(text.length);
        this.buffer.putUtf8Raw(text);
        trySendChannel(this.keyboard, this.buffer);
    }
    // -- Mouse
    onMouseDown(event, rect) {
        const button = convertToButton(event);
        if (button == null) {
            return;
        }
        if (this.config.mouseMode == "relative" || this.config.mouseMode == "follow") {
            this.sendMouseButton(true, button);
        }
        else if (this.config.mouseMode == "pointAndDrag") {
            this.sendMousePositionClientCoordinates(event.clientX, event.clientY, rect, true, button);
        }
    }
    onMouseUp(event) {
        const button = convertToButton(event);
        if (button == null) {
            return;
        }
        if (this.config.mouseMode == "relative" || this.config.mouseMode == "follow") {
            this.sendMouseButton(false, button);
        }
        else if (this.config.mouseMode == "pointAndDrag") {
            this.sendMouseButton(false, button);
        }
    }
    onMouseMove(event, rect) {
        if (this.config.mouseMode == "relative") {
            this.sendMouseMoveClientCoordinates(event.movementX, event.movementY, rect);
        }
        else if (this.config.mouseMode == "follow") {
            this.sendMousePositionClientCoordinates(event.clientX, event.clientY, rect, false);
        }
        else if (this.config.mouseMode == "pointAndDrag") {
            if (event.buttons) {
                // some button pressed
                this.sendMouseMoveClientCoordinates(event.movementX, event.movementY, rect);
            }
        }
    }
    onMouseWheel(event) {
        if (this.config.mouseScrollMode == "highres") {
            this.sendMouseWheelHighRes(event.deltaX, -event.deltaY);
        }
        else if (this.config.mouseScrollMode == "normal") {
            this.sendMouseWheel(event.deltaX, -event.deltaY);
        }
    }
    sendMouseMove(movementX, movementY) {
        this.buffer.reset();
        this.buffer.putU8(0);
        this.buffer.putI16(movementX);
        this.buffer.putI16(movementY);
        trySendChannel(this.mouseRelative, this.buffer);
    }
    sendMouseMoveClientCoordinates(movementX, movementY, rect) {
        const scaledMovementX = movementX / rect.width * this.streamerSize[0];
        const scaledMovementY = movementY / rect.height * this.streamerSize[1];
        this.sendMouseMove(scaledMovementX, scaledMovementY);
    }
    sendMousePosition(x, y, referenceWidth, referenceHeight, reliable) {
        var _a;
        this.buffer.reset();
        this.buffer.putU8(1);
        this.buffer.putI16(x);
        this.buffer.putI16(y);
        this.buffer.putI16(referenceWidth);
        this.buffer.putI16(referenceHeight);
        if (reliable) {
            trySendChannel(this.mouseReliable, this.buffer);
        }
        else {
            const PACKET_SIZE = 1 + 2 + 2 + 2 + 2;
            const estimatedBufferedBytes = (_a = this.mouseAbsolute) === null || _a === void 0 ? void 0 : _a.estimatedBufferedBytes();
            if (this.mouseAbsolute && estimatedBufferedBytes != null && estimatedBufferedBytes > PACKET_SIZE) {
                return;
            }
            trySendChannel(this.mouseAbsolute, this.buffer);
        }
    }
    sendMousePositionClientCoordinates(clientX, clientY, rect, reliable, mouseButton) {
        const position = this.calcNormalizedPosition(clientX, clientY, rect);
        if (position) {
            const [x, y] = position;
            this.sendMousePosition(x * 4096.0, y * 4096.0, 4096.0, 4096.0, reliable);
            if (mouseButton != undefined) {
                this.sendMouseButton(true, mouseButton);
            }
        }
    }
    // Note: button = StreamMouseButton.
    sendMouseButton(isDown, button) {
        this.buffer.reset();
        this.buffer.putU8(2);
        this.buffer.putBool(isDown);
        this.buffer.putU8(button);
        trySendChannel(this.mouseReliable, this.buffer);
    }
    sendMouseWheelHighRes(deltaX, deltaY) {
        this.buffer.reset();
        this.buffer.putU8(3);
        this.buffer.putI16(deltaX);
        this.buffer.putI16(deltaY);
        trySendChannel(this.mouseRelative, this.buffer);
    }
    sendMouseWheel(deltaX, deltaY) {
        this.buffer.reset();
        this.buffer.putU8(4);
        this.buffer.putI8(deltaX);
        this.buffer.putI8(deltaY);
        trySendChannel(this.mouseRelative, this.buffer);
    }
    onTouchData(data) {
        const buffer = new ByteBuffer(new Uint8Array(data));
        this.touchSupported = buffer.getBool();
    }
    updateTouchTracker(touch) {
        const oldTouch = this.touchTracker.get(touch.identifier);
        if (!oldTouch) {
            this.touchTracker.set(touch.identifier, {
                startTime: Date.now(),
                originX: touch.clientX,
                originY: touch.clientY,
                x: touch.clientX,
                y: touch.clientY,
                mouseMoved: false,
                mouseClicked: false
            });
        }
        else {
            oldTouch.x = touch.clientX;
            oldTouch.y = touch.clientY;
        }
    }
    calcTouchTime(touch) {
        return Date.now() - touch.startTime;
    }
    calcTouchOriginDistance(touch, oldTouch) {
        if ("clientX" in touch) {
            return Math.hypot(touch.clientX - oldTouch.originX, touch.clientY - oldTouch.originY);
        }
        else {
            return Math.hypot(touch.x - oldTouch.originX, touch.y - oldTouch.originY);
        }
    }
    onTouchStart(event, rect) {
        for (const touch of event.changedTouches) {
            this.updateTouchTracker(touch);
        }
        if (this.config.touchMode == "touch") {
            for (const touch of event.changedTouches) {
                this.sendTouch(0, touch, rect);
            }
        }
        else if (this.config.touchMode == "mouseRelative" || this.config.touchMode == "pointAndDrag") {
            for (const touch of event.changedTouches) {
                if (this.primaryTouch == null) {
                    this.primaryTouch = touch.identifier;
                    this.touchMouseAction = "default";
                }
            }
            if (this.primaryTouch != null && this.touchTracker.size == 2) {
                const primaryTouch = this.touchTracker.get(this.primaryTouch);
                if (primaryTouch && !primaryTouch.mouseMoved && !primaryTouch.mouseClicked) {
                    this.touchMouseAction = "scroll";
                    if (this.config.touchMode == "pointAndDrag") {
                        let middleX = 0;
                        let middleY = 0;
                        for (const touch of this.touchTracker.values()) {
                            middleX += touch.x;
                            middleY += touch.y;
                        }
                        // Tracker size = 2 so there will only be 2 elements
                        middleX /= 2;
                        middleY /= 2;
                        primaryTouch.mouseMoved = true;
                        this.sendMousePositionClientCoordinates(middleX, middleY, rect, true);
                    }
                }
            }
            else if (this.touchTracker.size == 3) {
                this.touchMouseAction = "screenKeyboard";
            }
        }
    }
    onTouchUpdate(rect) {
        if (this.config.touchMode == "pointAndDrag") {
            if (this.primaryTouch == null) {
                return;
            }
            const touch = this.touchTracker.get(this.primaryTouch);
            if (!touch) {
                return;
            }
            const time = this.calcTouchTime(touch);
            if (this.touchMouseAction == "default" && !touch.mouseMoved && time >= TOUCH_AS_CLICK_MIN_TIME_MS) {
                this.sendMousePositionClientCoordinates(touch.originX, touch.originY, rect, true);
                touch.mouseMoved = true;
            }
        }
    }
    onTouchMove(event, rect) {
        if (this.config.touchMode == "touch") {
            for (const touch of event.changedTouches) {
                this.sendTouch(1, touch, rect);
            }
        }
        else if (this.config.touchMode == "mouseRelative" || this.config.touchMode == "pointAndDrag") {
            for (const touch of event.changedTouches) {
                if (this.primaryTouch != touch.identifier) {
                    continue;
                }
                const oldTouch = this.touchTracker.get(this.primaryTouch);
                if (!oldTouch) {
                    continue;
                }
                // mouse move
                const movementX = touch.clientX - oldTouch.x;
                const movementY = touch.clientY - oldTouch.y;
                if (this.touchMouseAction == "default") {
                    this.sendMouseMoveClientCoordinates(movementX, movementY, rect);
                    const distance = this.calcTouchOriginDistance(touch, oldTouch);
                    if (this.config.touchMode == "pointAndDrag" && distance > TOUCH_AS_CLICK_MAX_DISTANCE) {
                        if (!oldTouch.mouseMoved) {
                            this.sendMousePositionClientCoordinates(touch.clientX, touch.clientY, rect, true);
                            oldTouch.mouseMoved = true;
                        }
                        if (!oldTouch.mouseClicked) {
                            this.sendMousePositionClientCoordinates(oldTouch.originX, oldTouch.originY, rect, true);
                            this.sendMouseButton(true, StreamMouseButton.LEFT);
                            oldTouch.mouseClicked = true;
                        }
                    }
                }
                else if (this.touchMouseAction == "scroll") {
                    // inverting horizontal scroll
                    if (this.config.mouseScrollMode == "highres") {
                        this.sendMouseWheelHighRes(-movementX * TOUCH_HIGH_RES_SCROLL_MULTIPLIER, movementY * TOUCH_HIGH_RES_SCROLL_MULTIPLIER);
                    }
                    else if (this.config.mouseScrollMode == "normal") {
                        this.sendMouseWheel(-movementX * TOUCH_SCROLL_MULTIPLIER, movementY * TOUCH_SCROLL_MULTIPLIER);
                    }
                }
                else if (this.touchMouseAction == "screenKeyboard") {
                    const distanceY = touch.clientY - oldTouch.originY;
                    if (distanceY < -TOUCHES_AS_KEYBOARD_DISTANCE) {
                        const customEvent = new CustomEvent("ml-screenkeyboardvisible", {
                            detail: { visible: true }
                        });
                        this.eventTarget.dispatchEvent(customEvent);
                    }
                    else if (distanceY > TOUCHES_AS_KEYBOARD_DISTANCE) {
                        const customEvent = new CustomEvent("ml-screenkeyboardvisible", {
                            detail: { visible: false }
                        });
                        this.eventTarget.dispatchEvent(customEvent);
                    }
                }
            }
        }
        for (const touch of event.changedTouches) {
            this.updateTouchTracker(touch);
        }
    }
    onTouchEnd(event, rect) {
        if (this.config.touchMode == "touch") {
            for (const touch of event.changedTouches) {
                this.sendTouch(2, touch, rect);
            }
        }
        else if (this.config.touchMode == "mouseRelative" || this.config.touchMode == "pointAndDrag") {
            for (const touch of event.changedTouches) {
                if (this.primaryTouch != touch.identifier) {
                    continue;
                }
                const oldTouch = this.touchTracker.get(this.primaryTouch);
                this.primaryTouch = null;
                if (oldTouch) {
                    const time = this.calcTouchTime(oldTouch);
                    const distance = this.calcTouchOriginDistance(touch, oldTouch);
                    if (this.touchMouseAction == "default") {
                        if (distance <= TOUCH_AS_CLICK_MAX_DISTANCE) {
                            if (time <= TOUCH_AS_CLICK_MAX_TIME_MS || oldTouch.mouseClicked) {
                                if (this.config.touchMode == "pointAndDrag" && !oldTouch.mouseMoved) {
                                    this.sendMousePositionClientCoordinates(touch.clientX, touch.clientY, rect, true);
                                }
                                if (!oldTouch.mouseClicked) {
                                    this.sendMouseButton(true, StreamMouseButton.LEFT);
                                }
                                this.sendMouseButton(false, StreamMouseButton.LEFT);
                            }
                            else {
                                this.sendMouseButton(true, StreamMouseButton.RIGHT);
                                this.sendMouseButton(false, StreamMouseButton.RIGHT);
                            }
                        }
                        else if (this.config.touchMode == "pointAndDrag") {
                            this.sendMouseButton(true, StreamMouseButton.LEFT);
                            this.sendMouseButton(false, StreamMouseButton.LEFT);
                        }
                    }
                }
            }
        }
        for (const touch of event.changedTouches) {
            this.touchTracker.delete(touch.identifier);
        }
    }
    onTouchCancel(event, rect) {
        this.onTouchEnd(event, rect);
    }
    calcNormalizedPosition(clientX, clientY, rect) {
        const x = (clientX - rect.left) / rect.width;
        const y = (clientY - rect.top) / rect.height;
        if (x < 0 || x > 1.0 || y < 0 || y > 1.0) {
            // invalid touch
            return null;
        }
        return [x, y];
    }
    sendTouch(type, touch, rect) {
        this.buffer.reset();
        this.buffer.putU8(type);
        this.buffer.putU32(touch.identifier);
        const position = this.calcNormalizedPosition(touch.clientX, touch.clientY, rect);
        if (!position) {
            return;
        }
        const [x, y] = position;
        this.buffer.putF32(x);
        this.buffer.putF32(y);
        this.buffer.putF32(touch.force);
        this.buffer.putF32(touch.radiusX);
        this.buffer.putF32(touch.radiusY);
        this.buffer.putU16(touch.rotationAngle);
        trySendChannel(this.touch, this.buffer);
    }
    isTouchSupported() {
        return this.touchSupported;
    }
    getCurrentPredictedTouchAction() {
        return this.touchMouseAction;
    }
    registerBufferedControllers() {
        const gamepads = navigator.getGamepads();
        for (const index of this.bufferedControllers.splice(0)) {
            const gamepad = gamepads[index];
            if (gamepad) {
                this.onGamepadConnect(gamepad);
            }
        }
    }
    collectActuators(gamepad) {
        const actuators = [];
        if ("vibrationActuator" in gamepad && gamepad.vibrationActuator) {
            actuators.push(gamepad.vibrationActuator);
        }
        if ("hapticActuators" in gamepad && gamepad.hapticActuators) {
            const hapticActuators = gamepad.hapticActuators;
            actuators.push(...hapticActuators);
        }
        return actuators;
    }
    onGamepadConnect(gamepad) {
        if (!this.connected) {
            this.bufferedControllers.push(gamepad.index);
            return;
        }
        if (this.gamepads.find(value => (value === null || value === void 0 ? void 0 : value.gamepadIndex) == gamepad.index)) {
            return;
        }
        let id = -1;
        for (let i = 0; i < this.gamepads.length; i++) {
            if (this.gamepads[i] == null) {
                this.gamepads[i] = { gamepadIndex: gamepad.index, oldState: emptyGamepadState() };
                id = i;
                break;
            }
        }
        if (id == -1) {
            id = this.gamepads.length;
            this.gamepads.push({ gamepadIndex: gamepad.index, oldState: emptyGamepadState() });
        }
        // Start Rumble interval
        if (this.gamepadRumbleInterval == null) {
            this.gamepadRumbleInterval = window.setInterval(this.onGamepadRumbleInterval.bind(this), CONTROLLER_RUMBLE_INTERVAL_MS - 10);
        }
        // Reset rumble
        this.gamepadRumbleCurrent[0] = { lowFrequencyMotor: 0, highFrequencyMotor: 0, leftTrigger: 0, rightTrigger: 0 };
        let capabilities = 0;
        // Rumble capabilities
        for (const actuator of this.collectActuators(gamepad)) {
            if ("effects" in actuator) {
                const supportedEffects = actuator.effects;
                for (const effect of supportedEffects) {
                    if (effect == "dual-rumble") {
                        capabilities = StreamControllerCapabilities.CAPABILITY_RUMBLE;
                    }
                    else if (effect == "trigger-rumble") {
                        capabilities = StreamControllerCapabilities.CAPABILITY_TRIGGER_RUMBLE;
                    }
                }
            }
            else if ("type" in actuator && (actuator.type == "vibration" || actuator.type == "dual-rumble")) {
                capabilities = StreamControllerCapabilities.CAPABILITY_RUMBLE;
            }
            else if ("playEffect" in actuator && typeof actuator.playEffect == "function") {
                // we're just hoping at this point
                capabilities = StreamControllerCapabilities.CAPABILITY_RUMBLE | StreamControllerCapabilities.CAPABILITY_TRIGGER_RUMBLE;
            }
            else if ("pulse" in actuator && typeof actuator.pulse == "function") {
                capabilities = StreamControllerCapabilities.CAPABILITY_RUMBLE;
            }
        }
        this.sendControllerAdd(this.gamepads.length - 1, SUPPORTED_BUTTONS, capabilities);
        if (gamepad.mapping != "standard") {
            console.warn(`[Gamepad]: Unable to read values of gamepad with mapping ${gamepad.mapping}`);
        }
    }
    onGamepadDisconnect(event) {
        var _a;
        const index = this.gamepads.findIndex(value => (value === null || value === void 0 ? void 0 : value.gamepadIndex) == event.gamepad.index);
        if (index != -1) {
            const id = (_a = this.gamepads[index]) === null || _a === void 0 ? void 0 : _a.gamepadIndex;
            if (id != null) {
                this.sendControllerRemove(id);
            }
            this.gamepads[index] = null;
        }
    }
    onGamepadUpdate() {
        if (this.config.controllerConfig.sendIntervalOverride != null) {
            const now = performance.now();
            if (now - this.lastGamepadUpdate < (1000 / this.config.controllerConfig.sendIntervalOverride)) {
                return;
            }
            this.lastGamepadUpdate = performance.now();
        }
        for (let gamepadId = 0; gamepadId < this.gamepads.length; gamepadId++) {
            const oldGamepadState = this.gamepads[gamepadId];
            if (oldGamepadState == null) {
                return;
            }
            const gamepad = navigator.getGamepads()[oldGamepadState.gamepadIndex];
            if (!gamepad) {
                continue;
            }
            if (gamepad.mapping != "standard") {
                continue;
            }
            const state = extractGamepadState(gamepad, this.config.controllerConfig);
            if (state == oldGamepadState.oldState) {
                continue;
            }
            oldGamepadState.oldState = state;
            this.sendController(gamepadId, state);
        }
    }
    onControllerData(data) {
        var _a, _b;
        this.buffer.reset();
        this.buffer.putU8Array(new Uint8Array(data));
        this.buffer.flip();
        // TODO: maybe move this into their respective controller channels?
        const ty = this.buffer.getU8();
        if (ty == 0) {
            // Rumble
            const id = this.buffer.getU8();
            const lowFrequencyMotor = this.buffer.getU16() / U16_MAX;
            const highFrequencyMotor = this.buffer.getU16() / U16_MAX;
            const gamepadIndex = (_a = this.gamepads[id]) === null || _a === void 0 ? void 0 : _a.gamepadIndex;
            if (gamepadIndex == null) {
                return;
            }
            this.setGamepadEffect(gamepadIndex, "dual-rumble", { lowFrequencyMotor, highFrequencyMotor });
        }
        else if (ty == 1) {
            // Trigger Rumble
            const id = this.buffer.getU8();
            const leftTrigger = this.buffer.getU16() / U16_MAX;
            const rightTrigger = this.buffer.getU16() / U16_MAX;
            const gamepadIndex = (_b = this.gamepads[id]) === null || _b === void 0 ? void 0 : _b.gamepadIndex;
            if (gamepadIndex == null) {
                return;
            }
            this.setGamepadEffect(gamepadIndex, "trigger-rumble", { leftTrigger, rightTrigger });
        }
    }
    setGamepadEffect(id, _ty, params) {
        const rumble = this.gamepadRumbleCurrent[id];
        Object.assign(rumble, params);
    }
    onGamepadRumbleInterval() {
        var _a;
        for (let id = 0; id < this.gamepads.length; id++) {
            const gamepadIndex = (_a = this.gamepads[id]) === null || _a === void 0 ? void 0 : _a.gamepadIndex;
            if (gamepadIndex == null) {
                continue;
            }
            const rumble = this.gamepadRumbleCurrent[gamepadIndex];
            const gamepad = navigator.getGamepads()[gamepadIndex];
            if (gamepad && rumble) {
                this.refreshGamepadRumble(rumble, gamepad);
            }
        }
    }
    refreshGamepadRumble(rumble, gamepad) {
        // Browsers are making this more complicated than it is
        const actuators = this.collectActuators(gamepad);
        for (const actuator of actuators) {
            if ("effects" in actuator) {
                const supportedEffects = actuator.effects;
                for (const effect of supportedEffects) {
                    if (effect == "dual-rumble") {
                        actuator.playEffect("dual-rumble", {
                            duration: CONTROLLER_RUMBLE_INTERVAL_MS,
                            weakMagnitude: rumble.lowFrequencyMotor,
                            strongMagnitude: rumble.highFrequencyMotor
                        });
                    }
                    else if (effect == "trigger-rumble") {
                        actuator.playEffect("trigger-rumble", {
                            duration: CONTROLLER_RUMBLE_INTERVAL_MS,
                            leftTrigger: rumble.leftTrigger,
                            rightTrigger: rumble.rightTrigger
                        });
                    }
                }
            }
            else if ("type" in actuator && (actuator.type == "vibration" || actuator.type == "dual-rumble")) {
                actuator.playEffect(actuator.type, {
                    duration: CONTROLLER_RUMBLE_INTERVAL_MS,
                    weakMagnitude: rumble.lowFrequencyMotor,
                    strongMagnitude: rumble.highFrequencyMotor
                });
            }
            else if ("playEffect" in actuator && typeof actuator.playEffect == "function") {
                actuator.playEffect("dual-rumble", {
                    duration: CONTROLLER_RUMBLE_INTERVAL_MS,
                    weakMagnitude: rumble.lowFrequencyMotor,
                    strongMagnitude: rumble.highFrequencyMotor
                });
                actuator.playEffect("trigger-rumble", {
                    duration: CONTROLLER_RUMBLE_INTERVAL_MS,
                    leftTrigger: rumble.leftTrigger,
                    rightTrigger: rumble.rightTrigger
                });
            }
            else if ("pulse" in actuator && typeof actuator.pulse == "function") {
                const weak = Math.min(Math.max(rumble.lowFrequencyMotor, 0), 1);
                const strong = Math.min(Math.max(rumble.highFrequencyMotor, 0), 1);
                const average = (weak + strong) / 2.0;
                actuator.pulse(average, CONTROLLER_RUMBLE_INTERVAL_MS);
            }
        }
    }
    // -- Controller Sending
    sendControllerAdd(id, supportedButtons, capabilities) {
        this.buffer.reset();
        this.buffer.putU8(0);
        this.buffer.putU8(id);
        this.buffer.putU32(supportedButtons);
        this.buffer.putU16(capabilities);
        trySendChannel(this.controllers, this.buffer);
    }
    sendControllerRemove(id) {
        this.buffer.reset();
        this.buffer.putU8(1);
        this.buffer.putU8(id);
        trySendChannel(this.controllers, this.buffer);
    }
    // Values
    // - Trigger: range 0..1
    // - Stick: range -1..1
    sendController(id, state) {
        const PACKET_SIZE_BYTES = 1 + 4 + 1 + 1 + 2 + 2 + 2 + 2;
        const controllerChannel = this.controllerInputs[id];
        const estimatedBufferedBytes = controllerChannel === null || controllerChannel === void 0 ? void 0 : controllerChannel.estimatedBufferedBytes();
        if (controllerChannel && estimatedBufferedBytes != null && estimatedBufferedBytes > PACKET_SIZE_BYTES) {
            // Only send packets when we can handle them
            console.debug(`dropping controller packet for ${id} because the buffer amount is large enough: ${controllerChannel.estimatedBufferedBytes()}`);
            return;
        }
        this.buffer.reset();
        this.buffer.putU8(0);
        this.buffer.putU32(state.buttonFlags);
        this.buffer.putU8(Math.max(0.0, Math.min(1.0, state.leftTrigger)) * U8_MAX);
        this.buffer.putU8(Math.max(0.0, Math.min(1.0, state.rightTrigger)) * U8_MAX);
        this.buffer.putI16(Math.max(-1.0, Math.min(1.0, state.leftStickX)) * I16_MAX);
        this.buffer.putI16(Math.max(-1.0, Math.min(1.0, -state.leftStickY)) * I16_MAX);
        this.buffer.putI16(Math.max(-1.0, Math.min(1.0, state.rightStickX)) * I16_MAX);
        this.buffer.putI16(Math.max(-1.0, Math.min(1.0, -state.rightStickY)) * I16_MAX);
        trySendChannel(this.controllerInputs[id], this.buffer);
    }
}
